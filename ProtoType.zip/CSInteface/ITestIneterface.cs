﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSInteface
{
    public interface ITestIneterface : IDisposable
    {
        event Action<object, string> OnNotify;
        void Init();
        void Run();
        void InGoingMessage(string message);
        void Stop();
    }
}
