﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ProtoType
{
    public class Entry :IDisposable
    {
        private ConcurrentDictionary<string, ProcessObject> _processes;
        private bool _disposed;
        public Entry()
        {
            _processes = new ConcurrentDictionary<string, ProcessObject>();
        }
        protected void Dispose(bool isDispose)
        {
            foreach(var p in _processes)
            {
                p.Value.CancellationToken.Cancel();
            }
            _processes.Clear();
            _disposed = isDispose;
        }
        public void Dispose()
        {
            if (_disposed)
                return;
            Dispose(true);
        }
        //각 DLL로 부터 Notify가 들어오는 구간
        private void OnNotify(object sender, string message)
        {
            Console.WriteLine($"Hub(Center) Notify Recive : {message}");
            //등록되어 있는 Dll 클래스에게 Notify 전달
            foreach (var item in _processes)
            {
                var method = item.Value.DllProcess.GetType().GetMethod("InGoingMessage", System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.Instance);
                method?.Invoke(item.Value.DllProcess, new object[] { message });
            }
        }
        private void ProcessStart(object process)
        {
            ProcessObject state = process as ProcessObject;
            var stopMethod = state.DllProcess.GetType().GetMethod("Stop", System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.Public);
            while (!state.CancellationToken.IsCancellationRequested)
            {
                try
                {
                    if (state.Started)
                        continue;

                    var initMethod = state.DllProcess.GetType().GetMethod("Init", System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.Public);
                    initMethod?.Invoke(state.DllProcess, null);

                    var runMethod = state.DllProcess.GetType().GetMethod("Run", System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.Public);
                    runMethod?.Invoke(state.DllProcess, null);

                    state.Started = true;
                }
                catch(Exception ex)
                {
                    stopMethod?.Invoke(state.DllProcess, null);
                    state.Started = false;
                    Trace.WriteLine(ex.Message);
                }
                finally
                {
                    Thread.Sleep(1000);
                }
            }
            if (state.DllProcess is CSInteface.ITestIneterface)
            {
                var p = state.DllProcess as CSInteface.ITestIneterface;
                p.OnNotify -= OnNotify;
            }
            else if (state.DllProcess is ITestIneterface)
            {
                var p = state.DllProcess as ITestIneterface;
                p.OnNotify -= OnNotify;
            }
            stopMethod? .Invoke(state.DllProcess, null);
            Console.WriteLine($"Thread Close");
        }
        public void Start()
        {
            var assem = AppDomain.CurrentDomain.GetAssemblies();
            foreach (var meta in assem)
            {
                var types = meta.GetExportedTypes().Where(r => r.IsClass &&
                                                            (r.Equals(typeof(ITestIneterface)) ||
                                                            r.GetInterfaces().Any(i => i.Equals(typeof(CSInteface.ITestIneterface))
                                                            ))).ToList();
                foreach (var type in types)
                {
                    var process = new ProcessObject();
                    process.CancellationToken = new CancellationTokenSource();

                    process.DllProcess = Activator.CreateInstance(type);
                    if (process.DllProcess is CSInteface.ITestIneterface)
                    {
                        var p = process.DllProcess as CSInteface.ITestIneterface;
                        p.OnNotify += OnNotify; //옵저버 패턴 생각하면 됨
                    }
                    else if (process.DllProcess is ITestIneterface)
                    {
                        var p = process.DllProcess as ITestIneterface;
                        p.OnNotify += OnNotify; //옵저버 패턴 생각하면 됨
                    }
                    _processes.TryAdd(type.Name, process);
                }   
            }
            foreach (var process in _processes)
            {
                ThreadPool.QueueUserWorkItem(ProcessStart, process.Value);
            }
        }
    }
}
