﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProtoType
{
    class Program
    {
        static void Main(string[] args)
        {
            //Dll 로딩을 안해서 Dll 로딩하게 생성만
            var t = new ITestIneterface();
            //t.Init();

            var cs = new NativeCS.Native();
            //cs.Init();

            var entry = new Entry();
            entry.Start();
            Console.ReadKey();
            entry.Dispose();//thread destroy check
            Console.WriteLine("Press key Program Close");
            Console.ReadKey();
        }
    }
}
