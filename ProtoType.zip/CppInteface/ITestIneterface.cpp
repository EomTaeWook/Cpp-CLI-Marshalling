#include "ITestInterface.h"
#include <msclr/marshal_cppstd.h>
void ITestIneterface::Init()
{
	auto cb = gcnew OnNotifyCallback(this, &ITestIneterface::OutGoingMessage);
	System::IntPtr ptr = System::Runtime::InteropServices::Marshal::GetFunctionPointerForDelegate(cb);
	_native->Init(static_cast<Native::OutGoingCallback>(ptr.ToPointer()));
}
void ITestIneterface::Run()
{
}
void ITestIneterface::Stop()
{
	_native->Stop();
}
void ITestIneterface::InGoingMessage(System::String^ inGoingMessage)
{
	std::string message = msclr::interop::marshal_as<std::string>(inGoingMessage);
	_native->InGoinMessage(message);
}
//Native �ܿ��� �Ѱܹ��� Message�� �����ϰ� �ִ� ��� �ֵ����� Notify
void ITestIneterface::OutGoingMessage(std::string outGoingMessage)
{
	System::String^ message = gcnew System::String(outGoingMessage.c_str());
	OnNotify(this, message);
}